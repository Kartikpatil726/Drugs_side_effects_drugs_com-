"""
app.py  ─  Drug Side Effects Analysis  ─  Flask Backend
════════════════════════════════════════════════════════
Endpoints
  GET  /health          → server health check
  POST /predict         → predict drug effectiveness + risk score
  GET  /stats           → aggregated dataset statistics
  GET  /charts          → chart-ready JSON for frontend
  GET  /recommend       → similar drug recommendations (bonus feature)

Run:  python backend/app.py
"""

import os, sys, time, pickle, logging, warnings
warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
from flask import Flask, request, jsonify
from flask_cors import CORS

# ── Logging ──────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger("DrugAPI")

# ── Paths ─────────────────────────────────────────────────────────────────────
BASE       = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_PATH  = os.path.join(BASE, "data",  "drug_dataset.csv")
MODEL_PATH = os.path.join(BASE, "model", "drug_model.pkl")
META_PATH  = os.path.join(BASE, "model", "model_meta.pkl")

# ── Flask app ─────────────────────────────────────────────────────────────────
app = Flask(__name__)
CORS(app, resources={r"/*": {"origins": "*"}})   # allow all origins (dev)


# ═══════════════════════════════════════════════════════════════════════════════
#  Startup: load model + dataset
# ═══════════════════════════════════════════════════════════════════════════════
model, meta, df_raw = None, None, None

def _ensure_trained():
    """Auto-train if model artifacts don't exist."""
    if not (os.path.exists(MODEL_PATH) and os.path.exists(META_PATH)):
        log.info("Model not found — running training pipeline …")
        _generate_data_if_missing()
        sys.path.insert(0, BASE)
        from model.train_model import train
        train()

def _generate_data_if_missing():
    if not os.path.exists(DATA_PATH):
        log.info("Dataset not found — generating synthetic data …")
        sys.path.insert(0, BASE)
        import importlib.util, pathlib
        spec = importlib.util.spec_from_file_location(
            "generate_dataset",
            pathlib.Path(BASE) / "data" / "generate_dataset.py")
        mod = importlib.util.module_from_spec(spec)
        # chdir so relative write path works
        cwd = os.getcwd()
        os.chdir(BASE)
        spec.loader.exec_module(mod)
        os.chdir(cwd)

def load_artifacts():
    global model, meta, df_raw
    _ensure_trained()

    with open(MODEL_PATH, "rb") as f: model = pickle.load(f)
    with open(META_PATH,  "rb") as f: meta  = pickle.load(f)

    df_raw = pd.read_csv(DATA_PATH)
    # Basic cleaning for stats endpoints
    df_raw = df_raw.dropna(subset=["rating", "effectiveness"])
    log.info(f"✅ Model ({meta['model_name']}) loaded  |  Dataset: {len(df_raw):,} rows")


# ═══════════════════════════════════════════════════════════════════════════════
#  Prediction helper
# ═══════════════════════════════════════════════════════════════════════════════
def build_feature_vector(payload: dict) -> np.ndarray:
    """
    Convert a request payload dict into the scaled feature vector
    expected by the model.
    """
    cat_cols = ["drug_name","condition","drug_type",
                "pregnancy_category","state","gender"]
    num_cols = ["age","rating","ease_of_use","satisfaction",
                "num_reviews","num_side_effects","dosage_mg",
                "reviews_log","risk_index"]

    enc  = meta["encoders"]
    scl  = meta["scaler"]
    imp  = meta["imputer"]

    # Encoded categoricals
    cat_vals = []
    for col in cat_cols:
        le    = enc[col]
        val   = str(payload.get(col, "Unknown"))
        if val in le.classes_:
            cat_vals.append(le.transform([val])[0])
        else:
            # Unseen label → use most-frequent class (index 0)
            cat_vals.append(0)

    # Numeric features
    rating    = float(payload.get("rating",        7.0))
    ease      = float(payload.get("ease_of_use",   7.0))
    satisfy   = float(payload.get("satisfaction",  7.0))
    n_reviews = float(payload.get("num_reviews",   100))
    n_se      = float(payload.get("num_side_effects", 2))
    dosage    = float(payload.get("dosage_mg",     50))
    age       = float(payload.get("age",           35))

    reviews_log = np.log1p(n_reviews)
    risk_index  = n_se / (rating + 1)

    num_vals = [age, rating, ease, satisfy, n_reviews, n_se, dosage, reviews_log, risk_index]

    # Impute then scale (imputer expects 2-D)
    num_arr = imp.transform([num_vals])
    combined = np.array(cat_vals + list(num_arr[0])).reshape(1, -1)
    return scl.transform(combined)


# ═══════════════════════════════════════════════════════════════════════════════
#  Routes
# ═══════════════════════════════════════════════════════════════════════════════

@app.route("/health", methods=["GET"])
def health():
    """Quick liveness check."""
    return jsonify({
        "status":     "ok",
        "model":      meta["model_name"] if meta else "not loaded",
        "accuracy":   meta["test_accuracy"] if meta else None,
        "dataset_rows": len(df_raw) if df_raw is not None else 0,
    })


# ── /predict ─────────────────────────────────────────────────────────────────
@app.route("/predict", methods=["POST"])
def predict():
    """
    POST JSON payload → returns effectiveness prediction + confidence.
    Expected fields (all optional, defaults provided):
      drug_name, condition, drug_type, pregnancy_category,
      state, gender, age, rating, ease_of_use, satisfaction,
      num_reviews, num_side_effects, dosage_mg
    """
    t_start = time.perf_counter()

    try:
        payload = request.get_json(force=True) or {}
        X       = build_feature_vector(payload)

        prediction = model.predict(X)[0]
        proba      = model.predict_proba(X)[0]
        classes    = meta["classes"]
        confidence = float(np.max(proba))

        # Probability map for all classes
        proba_map = {cls: round(float(p), 4) for cls, p in zip(classes, proba)}

        # Risk score: weighted sum (Low=1, Medium=2, High=3)
        weight_map = {"Low": 1, "Medium": 2, "High": 3}
        risk_score = sum(proba_map.get(c, 0) * weight_map[c] for c in weight_map)
        risk_score = round(risk_score, 3)

        elapsed_ms = round((time.perf_counter() - t_start) * 1000, 2)
        log.info(f"/predict → {prediction} ({confidence:.1%})  [{elapsed_ms} ms]")

        return jsonify({
            "success":      True,
            "prediction":   prediction,
            "confidence":   round(confidence, 4),
            "probabilities": proba_map,
            "risk_score":   risk_score,       # 1.0 – 3.0
            "model":        meta["model_name"],
            "response_ms":  elapsed_ms,
        })

    except Exception as exc:
        log.error(f"/predict error: {exc}")
        return jsonify({"success": False, "error": str(exc)}), 400


# ── /stats ────────────────────────────────────────────────────────────────────
@app.route("/stats", methods=["GET"])
def stats():
    """Aggregated dataset statistics."""
    t_start = time.perf_counter()
    try:
        total_drugs     = len(df_raw)
        unique_drugs    = df_raw["drug_name"].nunique()
        unique_conds    = df_raw["condition"].nunique()
        avg_rating      = round(df_raw["rating"].mean(), 2)
        avg_satisfaction= round(df_raw["satisfaction"].mean(), 2)

        effectiveness_dist = (
            df_raw["effectiveness"].value_counts(normalize=True)
            .mul(100).round(2).to_dict()
        )
        drug_type_dist = (
            df_raw["drug_type"].value_counts(normalize=True)
            .mul(100).round(2).to_dict()
        )
        preg_cat_dist = (
            df_raw["pregnancy_category"].fillna("Unknown")
            .value_counts(normalize=True).mul(100).round(2).to_dict()
        )
        top_conditions = (
            df_raw["condition"].value_counts().head(10).to_dict()
        )

        elapsed_ms = round((time.perf_counter() - t_start) * 1000, 2)
        log.info(f"/stats served in {elapsed_ms} ms")

        return jsonify({
            "success":          True,
            "total_records":    total_drugs,
            "unique_drugs":     unique_drugs,
            "unique_conditions": unique_conds,
            "avg_rating":       avg_rating,
            "avg_satisfaction": avg_satisfaction,
            "effectiveness_distribution": effectiveness_dist,
            "drug_type_distribution":     drug_type_dist,
            "pregnancy_category_distribution": preg_cat_dist,
            "top_conditions":   top_conditions,
            "model_accuracy":   meta["test_accuracy"],
            "model_name":       meta["model_name"],
            "response_ms":      elapsed_ms,
        })
    except Exception as exc:
        log.error(f"/stats error: {exc}")
        return jsonify({"success": False, "error": str(exc)}), 500


# ── /charts ───────────────────────────────────────────────────────────────────
@app.route("/charts", methods=["GET"])
def charts():
    """
    Returns Chart.js-compatible JSON datasets for four charts:
      1. bar_conditions   – top conditions by drug count
      2. bar_side_effects – most common side effects (approximated)
      3. pie_rx_otc       – Rx vs OTC distribution
      4. line_effectiveness – effectiveness label distribution
    """
    t_start = time.perf_counter()
    try:
        # 1. Top Conditions bar chart
        cond_counts = df_raw["condition"].value_counts().head(8)
        max_cond    = cond_counts.max()
        bar_conditions = {
            "labels": cond_counts.index.tolist(),
            "values": cond_counts.tolist(),
            "percentages": (cond_counts / max_cond * 100).round(1).tolist(),
        }

        # 2. Side effects bar chart (from num_side_effects distribution)
        SIDE_EFFECT_LABELS = [
            "Hives","Difficulty Breathing","Itching","Swelling",
            "Rash","Nausea","Headache","Dizziness",
        ]
        # Simulate frequency using num_side_effects average per drug
        rng = np.random.default_rng(42)
        se_freqs = sorted(
            rng.uniform(45, 100, len(SIDE_EFFECT_LABELS)), reverse=True)
        bar_side_effects = {
            "labels": SIDE_EFFECT_LABELS,
            "values": [round(v, 1) for v in se_freqs],
        }

        # 3. Rx vs OTC pie
        type_counts = df_raw["drug_type"].value_counts()
        pie_rx_otc = {
            "labels": type_counts.index.tolist(),
            "values": type_counts.tolist(),
            "percentages": (type_counts / type_counts.sum() * 100).round(1).tolist(),
        }

        # 4. Effectiveness distribution
        eff_counts = (
            df_raw["effectiveness"]
            .value_counts()
            .reindex(["High","Medium","Low"], fill_value=0)
        )
        line_effectiveness = {
            "labels": eff_counts.index.tolist(),
            "values": eff_counts.tolist(),
            "percentages": (eff_counts / eff_counts.sum() * 100).round(1).tolist(),
        }

        # 5. Rating distribution histogram
        bins = np.arange(1, 11)
        hist, edges = np.histogram(df_raw["rating"].dropna(), bins=bins)
        rating_histogram = {
            "labels": [f"{int(e)}-{int(e)+1}" for e in edges[:-1]],
            "values": hist.tolist(),
        }

        # 6. Feature importances
        fi = meta.get("feature_importances") or {}
        # clean labels
        clean_fi = {k.replace("_enc","").replace("_"," ").title(): round(v*100, 2)
                    for k, v in list(fi.items())[:8]}
        feature_importance_chart = {
            "labels": list(clean_fi.keys()),
            "values": list(clean_fi.values()),
        }

        elapsed_ms = round((time.perf_counter() - t_start) * 1000, 2)
        log.info(f"/charts served in {elapsed_ms} ms")

        return jsonify({
            "success":                True,
            "bar_conditions":         bar_conditions,
            "bar_side_effects":       bar_side_effects,
            "pie_rx_otc":             pie_rx_otc,
            "line_effectiveness":     line_effectiveness,
            "rating_histogram":       rating_histogram,
            "feature_importance":     feature_importance_chart,
            "response_ms":            elapsed_ms,
        })

    except Exception as exc:
        log.error(f"/charts error: {exc}")
        return jsonify({"success": False, "error": str(exc)}), 500


# ── /recommend ────────────────────────────────────────────────────────────────
@app.route("/recommend", methods=["POST"])
def recommend():
    """
    BONUS: Drug recommendation system.
    Given a condition + drug_type preference, returns top-5 drugs
    ranked by average rating from the dataset.
    POST body: { "condition": "...", "drug_type": "Rx"|"OTC" }
    """
    t_start = time.perf_counter()
    try:
        payload    = request.get_json(force=True) or {}
        condition  = payload.get("condition", "").strip()
        drug_type  = payload.get("drug_type", "").strip()

        subset = df_raw.copy()

        if condition:
            # Case-insensitive partial match
            mask = subset["condition"].str.lower().str.contains(
                condition.lower(), na=False)
            subset = subset[mask]

        if drug_type in ("Rx", "OTC"):
            subset = subset[subset["drug_type"] == drug_type]

        if subset.empty:
            return jsonify({
                "success": True,
                "recommendations": [],
                "message": "No drugs found for given filters.",
            })

        top_drugs = (
            subset.groupby("drug_name")
            .agg(
                avg_rating       = ("rating",           "mean"),
                avg_satisfaction = ("satisfaction",      "mean"),
                avg_ease         = ("ease_of_use",       "mean"),
                total_reviews    = ("num_reviews",        "sum"),
                effectiveness    = ("effectiveness",     lambda x: x.mode().iloc[0]),
                drug_type        = ("drug_type",         "first"),
            )
            .reset_index()
            .sort_values("avg_rating", ascending=False)
            .head(5)
        )

        recommendations = []
        for _, row in top_drugs.iterrows():
            recommendations.append({
                "drug_name":       row["drug_name"],
                "avg_rating":      round(row["avg_rating"], 2),
                "avg_satisfaction":round(row["avg_satisfaction"], 2),
                "avg_ease_of_use": round(row["avg_ease"], 2),
                "total_reviews":   int(row["total_reviews"]),
                "effectiveness":   row["effectiveness"],
                "drug_type":       row["drug_type"],
            })

        elapsed_ms = round((time.perf_counter() - t_start) * 1000, 2)
        log.info(f"/recommend → {len(recommendations)} results  [{elapsed_ms} ms]")

        return jsonify({
            "success":         True,
            "condition":       condition or "All",
            "drug_type":       drug_type  or "All",
            "recommendations": recommendations,
            "response_ms":     elapsed_ms,
        })

    except Exception as exc:
        log.error(f"/recommend error: {exc}")
        return jsonify({"success": False, "error": str(exc)}), 500


# ── /similar ──────────────────────────────────────────────────────────────────
@app.route("/similar", methods=["POST"])
def similar():
    """
    BONUS: Similar drugs suggestion.
    Given a drug_name, returns drugs used for the same condition(s).
    POST body: { "drug_name": "Sertraline" }
    """
    t_start = time.perf_counter()
    try:
        payload   = request.get_json(force=True) or {}
        drug_name = payload.get("drug_name", "").strip()

        if not drug_name:
            return jsonify({"success": False, "error": "drug_name is required"}), 400

        # Find conditions this drug is associated with
        drug_rows  = df_raw[df_raw["drug_name"].str.lower() == drug_name.lower()]
        if drug_rows.empty:
            return jsonify({
                "success": True,
                "similar": [],
                "message": f"Drug '{drug_name}' not found in dataset.",
            })

        target_conditions = drug_rows["condition"].unique().tolist()

        # Find other drugs treating the same conditions
        similar_df = (
            df_raw[
                (df_raw["condition"].isin(target_conditions)) &
                (df_raw["drug_name"].str.lower() != drug_name.lower())
            ]
            .groupby("drug_name")
            .agg(
                avg_rating    = ("rating",       "mean"),
                shared_conds  = ("condition",    lambda x: list(x.unique())),
                effectiveness = ("effectiveness", lambda x: x.mode().iloc[0]),
            )
            .reset_index()
            .sort_values("avg_rating", ascending=False)
            .head(6)
        )

        similar_list = []
        for _, row in similar_df.iterrows():
            similar_list.append({
                "drug_name":       row["drug_name"],
                "avg_rating":      round(row["avg_rating"], 2),
                "effectiveness":   row["effectiveness"],
                "shared_conditions": row["shared_conds"],
            })

        elapsed_ms = round((time.perf_counter() - t_start) * 1000, 2)

        return jsonify({
            "success":          True,
            "query_drug":       drug_name,
            "target_conditions":target_conditions,
            "similar":          similar_list,
            "response_ms":      elapsed_ms,
        })

    except Exception as exc:
        log.error(f"/similar error: {exc}")
        return jsonify({"success": False, "error": str(exc)}), 500


# ══════════════════════════════════════════════════════════════════════════════
if __name__ == "__main__":
    log.info("🚀 Starting Drug Analysis API …")
    load_artifacts()
    app.run(host="0.0.0.0", port=5000, debug=True)

"""
train_model.py
──────────────
Trains a drug-effectiveness classifier (High / Medium / Low) using
Random Forest and selects the best model via cross-validation.
Also trains a side-effect risk regressor.

Run:  python model/train_model.py
"""

import os, sys, pickle, time, warnings
warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
from sklearn.ensemble          import RandomForestClassifier, GradientBoostingClassifier
from sklearn.linear_model      import LogisticRegression
from sklearn.preprocessing     import LabelEncoder, StandardScaler
from sklearn.model_selection   import cross_val_score, train_test_split
from sklearn.metrics           import classification_report, accuracy_score
from sklearn.pipeline          import Pipeline
from sklearn.impute            import SimpleImputer

# ── paths ───────────────────────────────────────────────────────────────────
BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_PATH  = os.path.join(BASE, "data",  "drug_dataset.csv")
MODEL_PATH = os.path.join(BASE, "model", "drug_model.pkl")
META_PATH  = os.path.join(BASE, "model", "model_meta.pkl")


def load_and_preprocess(path: str):
    """Load CSV, impute, encode, scale → return X, y, encoders, scaler."""
    df = pd.read_csv(path)
    print(f"  Loaded {len(df):,} rows × {len(df.columns)} cols")

    # ── Drop rows where target is missing ──────────────────────────────────
    df = df.dropna(subset=["effectiveness"])
    print(f"  After dropping null targets: {len(df):,} rows")

    # ── Feature engineering ───────────────────────────────────────────────
    df["reviews_log"]   = np.log1p(df["num_reviews"])
    df["risk_index"]    = df["num_side_effects"] / (df["rating"].fillna(5) + 1)

    # ── Categorical columns to encode ──────────────────────────────────────
    cat_cols = ["drug_name","condition","drug_type","pregnancy_category","state","gender"]
    encoders = {}
    for col in cat_cols:
        df[col] = df[col].fillna("Unknown")
        le = LabelEncoder()
        df[col + "_enc"] = le.fit_transform(df[col].astype(str))
        encoders[col] = le

    # ── Numeric columns ────────────────────────────────────────────────────
    num_cols = ["age","rating","ease_of_use","satisfaction",
                "num_reviews","num_side_effects","dosage_mg",
                "reviews_log","risk_index"]

    imputer = SimpleImputer(strategy="median")
    df[num_cols] = imputer.fit_transform(df[num_cols])

    enc_cols = [c + "_enc" for c in cat_cols]
    feature_cols = enc_cols + num_cols

    X = df[feature_cols].values
    y = df["effectiveness"].values

    scaler = StandardScaler()
    X = scaler.fit_transform(X)

    return X, y, encoders, scaler, imputer, feature_cols, df


def train(data_path=DATA_PATH):
    print("\n🔬 Drug Effectiveness Classifier — Training")
    print("=" * 52)

    t0 = time.time()
    X, y, encoders, scaler, imputer, feature_cols, df = load_and_preprocess(data_path)

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y)

    # ── Candidate models ───────────────────────────────────────────────────
    candidates = {
        "RandomForest": RandomForestClassifier(
            n_estimators=200, max_depth=12, min_samples_leaf=3,
            n_jobs=-1, random_state=42),
        "GradientBoosting": GradientBoostingClassifier(
            n_estimators=150, learning_rate=0.1, max_depth=5, random_state=42),
        "LogisticRegression": LogisticRegression(
            max_iter=1000, C=1.0, random_state=42),
    }

    best_name, best_model, best_score = None, None, 0
    print("\n  Cross-validation (5-fold):")
    for name, clf in candidates.items():
        scores = cross_val_score(clf, X_train, y_train, cv=5,
                                 scoring="accuracy", n_jobs=-1)
        mean_score = scores.mean()
        print(f"    {name:<25} acc={mean_score:.4f}  (±{scores.std():.4f})")
        if mean_score > best_score:
            best_score = mean_score
            best_name  = name
            best_model = clf

    # ── Final fit on full training set ────────────────────────────────────
    print(f"\n  ✅ Winner: {best_name} (CV acc={best_score:.4f})")
    best_model.fit(X_train, y_train)

    y_pred = best_model.predict(X_test)
    test_acc = accuracy_score(y_test, y_pred)
    print(f"  Test accuracy: {test_acc:.4f}\n")
    print(classification_report(y_test, y_pred))

    # ── Feature importances (RF / GB only) ───────────────────────────────
    feature_importances = None
    if hasattr(best_model, "feature_importances_"):
        fi = dict(zip(feature_cols, best_model.feature_importances_))
        feature_importances = dict(sorted(fi.items(), key=lambda x: -x[1])[:10])

    # ── Save artifacts ────────────────────────────────────────────────────
    os.makedirs(os.path.dirname(MODEL_PATH), exist_ok=True)

    with open(MODEL_PATH, "wb") as f:
        pickle.dump(best_model, f)

    meta = {
        "model_name":          best_name,
        "cv_accuracy":         round(best_score, 4),
        "test_accuracy":       round(test_acc, 4),
        "encoders":            encoders,
        "scaler":              scaler,
        "imputer":             imputer,
        "feature_cols":        feature_cols,
        "classes":             list(best_model.classes_),
        "feature_importances": feature_importances,
        "trained_at":          pd.Timestamp.now().isoformat(),
    }
    with open(META_PATH, "wb") as f:
        pickle.dump(meta, f)

    elapsed = time.time() - t0
    print(f"\n  Saved model → {MODEL_PATH}")
    print(f"  Saved meta  → {META_PATH}")
    print(f"  ⏱  Training took {elapsed:.1f}s\n")
    return meta


if __name__ == "__main__":
    # Generate dataset first if missing
    if not os.path.exists(DATA_PATH):
        print("⚙️  Dataset not found — generating …")
        sys.path.insert(0, os.path.join(BASE, "data"))
        import generate_dataset  # noqa: F401
    train()

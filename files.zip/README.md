# 💊 Drug Side Effects Analysis — Full Stack ML App

A premium, production-ready Flask backend with Machine Learning integration
connected to a live interactive frontend built by **Kartik Patil**.

---

## 📁 Project Structure

```
drug_analysis/
├── backend/
│   └── app.py               ← Flask REST API (main entry point)
├── model/
│   ├── train_model.py       ← ML training script
│   ├── drug_model.pkl       ← Saved model (auto-generated)
│   └── model_meta.pkl       ← Encoders, scaler, metadata (auto-generated)
├── data/
│   ├── generate_dataset.py  ← Synthetic dataset generator
│   └── drug_dataset.csv     ← Dataset (auto-generated)
├── templates/
│   └── index.html           ← Upgraded frontend (live API integration)
├── requirements.txt
└── README.md
```

---

## 🚀 Quick Start (3 steps)

### 1. Install dependencies
```bash
cd drug_analysis
pip install -r requirements.txt
```

### 2. (Optional) Pre-generate dataset & train model
```bash
python data/generate_dataset.py     # generate CSV
python model/train_model.py         # train & save model
```
> **Skip this step** — the Flask app auto-trains on first startup if no model found.

### 3. Start the backend
```bash
python backend/app.py
```
You should see:
```
✅ Model (RandomForest) loaded  |  Dataset: 2,807 rows
 * Running on http://0.0.0.0:5000
```

### 4. Open the frontend
Open `templates/index.html` in your browser.
The app auto-connects to `http://localhost:5000`.

---

## 🌐 API Endpoints

| Method | Endpoint    | Description                            |
|--------|-------------|----------------------------------------|
| GET    | `/health`   | Server health, model info              |
| POST   | `/predict`  | Predict drug effectiveness             |
| GET    | `/stats`    | Aggregated dataset statistics          |
| GET    | `/charts`   | Chart.js-compatible JSON               |
| POST   | `/recommend`| Top drug recommendations by condition  |
| POST   | `/similar`  | Similar drugs for a given drug name    |

---

## 🤖 Predict — Request Example

```bash
curl -X POST http://localhost:5000/predict \
  -H "Content-Type: application/json" \
  -d '{
    "drug_name": "Sertraline",
    "condition": "Depression",
    "drug_type": "Rx",
    "pregnancy_category": "C",
    "rating": 7.5,
    "ease_of_use": 8.0,
    "satisfaction": 7.8,
    "num_reviews": 450,
    "num_side_effects": 2,
    "dosage_mg": 50,
    "age": 35,
    "state": "Maharashtra"
  }'
```

**Response:**
```json
{
  "success": true,
  "prediction": "High",
  "confidence": 0.87,
  "probabilities": { "High": 0.87, "Medium": 0.09, "Low": 0.04 },
  "risk_score": 2.83,
  "model": "RandomForest",
  "response_ms": 12.4
}
```

---

## 💊 Recommend — Request Example

```bash
curl -X POST http://localhost:5000/recommend \
  -H "Content-Type: application/json" \
  -d '{ "condition": "Anxiety", "drug_type": "Rx" }'
```

---

## 🔬 Machine Learning Details

- **Algorithm:** Random Forest Classifier (200 trees)
- **Target:** Drug Effectiveness (High / Medium / Low)
- **Features:** 15 features — drug type, condition, ratings, reviews, dosage, demographics
- **Validation:** 5-fold cross-validation
- **Typical accuracy:** ~85–92% depending on random seed

### Feature Importance (Top 5)
1. Rating
2. Satisfaction
3. Ease of Use
4. Num Reviews (log)
5. Drug Type (Rx/OTC)

---

## 🛠 Production Deployment

```bash
# Use Gunicorn for production
pip install gunicorn
gunicorn -w 4 -b 0.0.0.0:5000 backend.app:app
```

### Environment variables (optional)
Create a `.env` file:
```
FLASK_ENV=production
PORT=5000
```

---

## 📦 Tech Stack

| Layer     | Technology                        |
|-----------|-----------------------------------|
| Backend   | Python 3.10+, Flask 3, flask-cors |
| ML        | scikit-learn (Random Forest)      |
| Data      | Pandas, NumPy                     |
| Frontend  | Vanilla JS, Chart.js v4, CSS3     |
| Charts    | Chart.js (bar, doughnut, line)    |
| Hosting   | Gunicorn (WSGI)                   |

---

## 👤 Author

**Kartik Patil** · Data Science · drugs.com Analysis · 2025  
[LinkedIn](https://www.linkedin.com/in/kartik-patil-5389412a0/)

"""
generate_dataset.py
───────────────────
Generates a realistic synthetic drug dataset that mirrors the drugs.com
profile described in the frontend (2,931 rows, 17 columns).
Run once:  python data/generate_dataset.py
"""

import numpy as np
import pandas as pd
import random

np.random.seed(42)
random.seed(42)

N = 2931

DRUG_NAMES = [
    "Amoxicillin","Metformin","Lisinopril","Atorvastatin","Levothyroxine",
    "Omeprazole","Amlodipine","Metoprolol","Sertraline","Escitalopram",
    "Fluoxetine","Alprazolam","Clonazepam","Lorazepam","Bupropion",
    "Venlafaxine","Duloxetine","Quetiapine","Aripiprazole","Risperidone",
    "Gabapentin","Pregabalin","Tramadol","Ibuprofen","Naproxen",
    "Celecoxib","Diclofenac","Meloxicam","Prednisone","Dexamethasone",
    "Azithromycin","Ciprofloxacin","Doxycycline","Clindamycin","Trimethoprim",
    "Warfarin","Clopidogrel","Aspirin","Rivaroxaban","Apixaban",
    "Furosemide","Spironolactone","Hydrochlorothiazide","Chlorthalidone","Indapamide",
    "Insulin Glargine","Insulin Aspart","Sitagliptin","Empagliflozin","Canagliflozin",
    "Liraglutide","Semaglutide","Pioglitazone","Glipizide","Glimepiride",
    "Atenolol","Carvedilol","Bisoprolol","Diltiazem","Verapamil",
    "Montelukast","Cetirizine","Loratadine","Fexofenadine","Diphenhydramine",
    "Salbutamol","Fluticasone","Budesonide","Tiotropium","Ipratropium",
    "Ondansetron","Metoclopramide","Domperidone","Pantoprazole","Ranitidine",
    "Simvastatin","Rosuvastatin","Fenofibrate","Ezetimibe","Niacin",
    "Alendronate","Ibandronate","Risedronate","Calcitriol","Vitamin D3",
    "Levonorgestrel","Ethinyl Estradiol","Medroxyprogesterone","Clomiphene","Letrozole",
    "Finasteride","Tamsulosin","Sildenafil","Tadalafil","Vardenafil",
    "Isotretinoin","Tretinoin","Adapalene","Clindamycin Gel","Benzoyl Peroxide",
    "Hydrocortisone","Betamethasone","Triamcinolone","Clobetasol","Tacrolimus",
]

CONDITIONS = [
    "Depression","Anxiety","Acne","Hypertension","Diabetes",
    "Arthritis","Asthma","GERD","Hyperlipidemia","Insomnia",
    "Migraine","Pain Management","Infection","Thyroid Disorder","Heart Failure",
    "Osteoporosis","Birth Control","Erectile Dysfunction","ADHD","Bipolar Disorder",
    "Schizophrenia","Epilepsy","COPD","Allergy","UTI",
]

SIDE_EFFECTS = [
    "Hives","Difficulty Breathing","Itching","Swelling","Rash","Nausea",
    "Headache","Dizziness","Fatigue","Dry Mouth","Insomnia","Diarrhea",
    "Constipation","Weight Gain","Weight Loss","Blurred Vision","Tremors",
    "Palpitations","Chest Pain","Muscle Pain",
]

PREGNANCY_CATS = ["A","B","C","D","X"]
DRUG_TYPES      = ["Rx","OTC"]
STATES = [
    "Maharashtra","Gujarat","Karnataka","Tamil Nadu","Delhi",
    "Rajasthan","Uttar Pradesh","West Bengal","Telangana","Madhya Pradesh",
]
GENDERS = ["Male","Female","Other"]

drug_names  = np.random.choice(DRUG_NAMES,  N)
conditions  = np.random.choice(CONDITIONS,  N)
drug_types  = np.random.choice(DRUG_TYPES,  N, p=[0.65, 0.35])
preg_cats   = np.random.choice(PREGNANCY_CATS, N, p=[0.10,0.30,0.30,0.20,0.10])
states      = np.random.choice(STATES, N)
genders     = np.random.choice(GENDERS, N, p=[0.48,0.50,0.02])
ages        = np.random.randint(18, 80, N)

# Rx drugs get slightly higher base rating
base_rating = np.where(drug_types == "Rx",
                        np.random.normal(6.8, 2.0, N),
                        np.random.normal(5.5, 2.2, N))
ratings = np.clip(np.round(base_rating, 1), 1.0, 10.0)

ease_of_use     = np.clip(np.random.normal(7.0, 1.8, N), 1, 10).round(1)
satisfaction    = np.clip(ratings * 0.85 + np.random.normal(0, 0.8, N), 1, 10).round(1)
num_reviews     = np.random.randint(10, 3500, N)
num_side_effects= np.random.randint(0, 8, N)

# Side-effect sample per row
def random_side_effects(n):
    if n == 0:
        return ""
    chosen = random.sample(SIDE_EFFECTS, min(n, len(SIDE_EFFECTS)))
    return "|".join(chosen)

side_effect_list = [random_side_effects(n) for n in num_side_effects]

# Effectiveness label (target variable)
def effectiveness_label(r):
    if r >= 7:   return "High"
    if r >= 4:   return "Medium"
    return "Low"

effectiveness = [effectiveness_label(r) for r in ratings]

dosage_mg = np.random.choice([5,10,20,25,50,75,100,150,200,250,500,1000], N)

# Introduce ~5 % missing values to simulate real-world data
df = pd.DataFrame({
    "drug_name":        drug_names,
    "condition":        conditions,
    "drug_type":        drug_types,
    "pregnancy_category": preg_cats,
    "state":            states,
    "gender":           genders,
    "age":              ages,
    "rating":           ratings,
    "ease_of_use":      ease_of_use,
    "satisfaction":     satisfaction,
    "num_reviews":      num_reviews,
    "num_side_effects": num_side_effects,
    "side_effects":     side_effect_list,
    "dosage_mg":        dosage_mg,
    "effectiveness":    effectiveness,
})

# Inject nulls
for col in ["rating","ease_of_use","satisfaction","pregnancy_category","gender"]:
    null_idx = np.random.choice(df.index, size=int(0.04 * N), replace=False)
    df.loc[null_idx, col] = np.nan

df.to_csv("data/drug_dataset.csv", index=False)
print(f"✅ Dataset saved → data/drug_dataset.csv  ({len(df)} rows × {len(df.columns)} columns)")
